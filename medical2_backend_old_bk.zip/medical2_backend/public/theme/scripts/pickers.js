'use strict';

var demoFormPickers = function () {

  var contentStyle = $('.main-content')[0].style;

  function plugins() {

    $('.datepicker').datepicker();

    $('.timepicker').timepicker();

    $('.current-time').on('click', function () {
      $('.timepicker').timepicker('setTime', new Date());
    });

    $('.color-picker').colorpicker();

    $('.background-color').colorpicker().on('changeColor', function (ev) {
      contentStyle.backgroundColor = ev.color.toHex();
    });

    $('#reservationtime').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      format: 'MM/DD/YYYY h:mm A'
    });

    $('#colorpalette1').colorPalette().on('selectColor', function (e) {
      $('#selected-color1').val(e.color);
    });
  }

  return {
    init: function () {
      plugins();
    }
  };
}();

$(function () {
  demoFormPickers.init();
});
