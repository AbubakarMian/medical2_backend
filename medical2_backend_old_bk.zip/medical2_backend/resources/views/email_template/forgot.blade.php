<!DOCTYPE html>
<html>
<head>
    <title>Password Reset</title>
</head>
<body>
    <h1>{!! $details['subject'] !!}</h1>
    <p>{!! $details['from'] !!}</p>
    <p>Your password is :{!! $details['pass'] !!}</p>
    <p>{!! $details['body'] !!}</p>

    
   
    <p>Thank you</p>
</body>
</html>