<!DOCTYPE html>
<html>
<head>
    <title>Martinty App</title>
</head>
<body>   
    <p>Order Number {!!$details->request_no!!} status has been updated to {!!$details->status!!}</p> 
</body>
</html>