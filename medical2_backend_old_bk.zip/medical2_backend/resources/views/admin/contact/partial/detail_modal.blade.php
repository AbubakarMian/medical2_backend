<div class="modal fade msg-modal in" id="msgmodal" tabindex="-1" role="dialog" aria-hidden="false">
    <div class="modal-dialog modal-mg">
        <div class="modal-content" id="confirm">
            <div class="modal-header">
                <h4 class="modal-title">Message</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div id="my_msg_div" class="col-xs-12">

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>