<html>
    <body>
        @yield('content')
    </body>
</html>
