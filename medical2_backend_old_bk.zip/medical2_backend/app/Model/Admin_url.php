<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
// use Illuminate\Database\Eloquent\SoftDeletes;

class Admin_url extends Model
{
    // use SoftDeletes;
    protected $table='admin_url';


 }
